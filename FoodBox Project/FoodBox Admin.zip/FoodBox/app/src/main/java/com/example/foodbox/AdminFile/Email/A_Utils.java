package com.example.foodbox.AdminFile.Email;

public class A_Utils {

    //This is your from email
    public static final String EMAIL = "foodservice.cuh@gmail.com";

    //This is your from email password
    public static final String PASSWORD = "Suman_Gaurav@5026";
}
