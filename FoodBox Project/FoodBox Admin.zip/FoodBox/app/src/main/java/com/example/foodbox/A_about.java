package com.example.foodbox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class A_about extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_activity_about);
    }
}