package com.example.foodbox.User;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.foodbox.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

public class user_login extends AppCompatActivity {
    Button login;
    TextView forgotpass, signup;
    EditText email, pswd;

    CheckBox pass_checkbox;

    String mail, pass;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private DatabaseReference myRef,databaseReference;

    private ProgressDialog progressDialog;

    public void onStart() {
        super.onStart();
        FirebaseUser currentUser=mAuth.getCurrentUser();
        if(currentUser!=null){
            Intent i =new Intent(getApplicationContext(),Users_Dashboard.class);
            startActivity(i);
            finish();
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);
        login = (Button) findViewById(R.id.loginbtn);
        forgotpass = findViewById(R.id.forgot);
        signup = findViewById(R.id.register);
        email = findViewById(R.id.email);
        pswd = findViewById(R.id.password);

        progressDialog = new ProgressDialog(this);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        db = FirebaseFirestore.getInstance();

        //myRef = db.getReference("users");

       pass_checkbox = findViewById(R.id.pass_show);
       pass_checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
           @Override
           public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
               if(isChecked){
                   pswd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
               }else{
                   pswd.setTransformationMethod(PasswordTransformationMethod.getInstance());
               }
           }
       });


        forgotpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Click Success", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), forgot_password.class);
                startActivity(i);
            }
        });
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(user_login.this, Register.class);
                startActivity(i);
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login();
            }
        });
    }

    private void Login() {
        mail = email.getText().toString();
        pass = pswd.getText().toString();
        if (TextUtils.isEmpty(mail)) {
            email.setError("Enter Your Email");
            return;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(mail).matches()) {
            email.setError("Enter Valid Email");
            return;
        } else if (TextUtils.isEmpty(pass)) {
            pswd.setError("Enter Your Password");
            return;
        } else if (pass.length() < 8) {
            pswd.setError(("Length should be >= 8"));
            return;
        }
        progressDialog.setMessage("Loading,please wait...");
        progressDialog.show();
        progressDialog.setCanceledOnTouchOutside(false);


        db.collection("users").whereEqualTo("email",mail).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.getResult().size()>0){

              mAuth.signInWithEmailAndPassword(mail, pass)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

//                            SharedPreferences preferences=getSharedPreferences("MyPreferences",MODE_PRIVATE);
//                            SharedPreferences.Editor editor = preferences.edit();
//                            editor.putString("email",mail);
//                            editor.putString("pass",pass);
//                            editor.apply();




                            Toast.makeText(user_login.this, "Login Successfully", Toast.LENGTH_SHORT).show();

                            Intent i = new Intent(user_login.this, Users_Dashboard.class);
                            startActivity(i);
                            finish();

                        } else {
                            Toast.makeText(user_login.this, "User doesn't exists/Your email or password do not match", Toast.LENGTH_SHORT).show();
                        }

                    }
                });
            }else{
                    Toast.makeText(user_login.this,"Invalid User.",Toast.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();

            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });
    }
}