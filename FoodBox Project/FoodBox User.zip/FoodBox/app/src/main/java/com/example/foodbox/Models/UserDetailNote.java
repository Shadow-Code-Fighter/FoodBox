package com.example.foodbox.Models;

public class UserDetailNote {
    private String email;
    private String uid;
    private String phone_no;

    public UserDetailNote() {
    }

    public UserDetailNote(String email, String uid, String phone_no) {
        this.email = email;
        this.uid = uid;
        this.phone_no = phone_no;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPhone_no() {
        return phone_no;
    }

    public void setPhone_no(String phone_no) {
        this.phone_no = phone_no;
    }
}
