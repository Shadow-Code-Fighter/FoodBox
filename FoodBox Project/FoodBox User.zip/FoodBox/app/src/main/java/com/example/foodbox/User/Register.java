package com.example.foodbox.User;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.foodbox.Intro.IntroActivity;
import com.example.foodbox.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity {
    Button register;
    EditText name, email, pswd, phone;
    TextView Login;
    String uname, mail, pass, phoneno;

    CheckBox pass_checkbox;

    private FirebaseAuth mAuth;

    private FirebaseFirestore db;

    private ProgressDialog progressDialog;

    protected void onStart(){
        super.onStart();
        FirebaseUser currentUser=mAuth.getCurrentUser();
        if (currentUser!=null){
            Intent i= new Intent(getApplicationContext(),Users_Dashboard.class);
            startActivity(i);
            finish();
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        register = findViewById(R.id.registerbtn);
        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        pswd = findViewById(R.id.password);
        phone = findViewById(R.id.phone);
        Login = findViewById(R.id.login);
        progressDialog=new ProgressDialog(this);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        pass_checkbox = findViewById(R.id.pass_show);
        pass_checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    pswd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }else{
                    pswd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                uname = name.getText().toString();
                mail = email.getText().toString();
                pass = pswd.getText().toString();
                phoneno = phone.getText().toString();

                InputFilter[] filters = new InputFilter[1];
                filters[0] = new InputFilter.LengthFilter(10);
                phone.setFilters(filters);

                if (TextUtils.isEmpty(uname)) {
                    name.setError("Enter Your Name");
                    return;
                } else if (TextUtils.isEmpty(mail)) {
                    email.setError("Enter Your Email");
                    return;
                } else if (!Patterns.EMAIL_ADDRESS.matcher(mail).matches()) {
                    email.setError("Enter Valid Email");
                    return;
                } else if (TextUtils.isEmpty(pass)) {
                    pswd.setError("Enter Your Password");
                    return;
                } else if (pass.length() < 8) {
                    pswd.setError(("Length should be >= 8"));
                    return;
                } else if (TextUtils.isEmpty(phoneno)) {
                    phone.setError("Enter Your Phone Number");
                    return;
                } else if (!Patterns.PHONE.matcher(phoneno).matches() || phoneno.length() != 10) {
                    phone.setError("Invalid mobile number");
                    return;
                }
                progressDialog.setMessage("Loading,please wait...");
                progressDialog.show();
                progressDialog.setCanceledOnTouchOutside(false);

                      /* else if (!isValidEmail(mail)) {
                            email.setError("Invalid Email");
                            return;

                    }
                        private boolean isValidEmail(CharSequence target) {
                            return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
                        }*/


                      /*  Map<String, Object> user = new HashMap<>();
                        user.put("name", uname);
                        user.put("email", mail);
                        user.put("phone", phoneno);

                        db.collection("users")
                                .add(user)
                                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                    @Override
                                    public void onSuccess(DocumentReference documentReference) {
                                        Toast.makeText(register.this, "Successful", Toast.LENGTH_SHORT).show();
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(register.this, "Failed", Toast.LENGTH_SHORT).show();
                                    }
                                });*/
                createuser();
            }
        });


        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Register.this, user_login.class);
                startActivity(intent);
                finish();
            }
        });
    }


    private void createuser() {

       // Toast.makeText(Register.this, "user created" + mail + " " + pass, Toast.LENGTH_SHORT).show();
        mAuth.createUserWithEmailAndPassword(mail, pass)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(Register.this, "Successfully Registered", Toast.LENGTH_SHORT).show();
                            uploadData();


                        } else {
                            Toast.makeText(Register.this, task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                        }
                        progressDialog.dismiss();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Register.this, "Network Error", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void uploadData() {
        Map<String, Object> user = new HashMap<>();
        user.put("name", uname);
        user.put("email", mail);
        user.put("phone", phoneno);

        db.collection("users").document(mAuth.getCurrentUser().getUid()).set(user);
        Toast.makeText(Register.this, "Successful", Toast.LENGTH_SHORT).show();
        Intent i= new Intent(Register.this, IntroActivity.class);
        startActivity(i);

    }
}



