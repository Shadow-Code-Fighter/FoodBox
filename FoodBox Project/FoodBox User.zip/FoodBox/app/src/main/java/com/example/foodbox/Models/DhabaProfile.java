package com.example.foodbox.Models;

public class DhabaProfile {
    private String Restaurant;
    private String city;
    private String Address;
    private  String documentId;
    private String AdminImage;

    public DhabaProfile() {
    }

    public DhabaProfile(String restaurant, String city, String address, String documentId, String image) {
        Restaurant = restaurant;
        this.city = city;
        Address = address;
        this.documentId = documentId;
        this.AdminImage = image;
    }

    public String getRestaurant() {
        return Restaurant;
    }

    public void setRestaurant(String restaurant) {
        Restaurant = restaurant;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getAdminImage() {
        return AdminImage;
    }

    public void setAdminImage(String adminImage) {
        AdminImage = adminImage;
    }
}
