package com.example.foodbox.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.example.foodbox.Adapter.DhabaAdapter;
import com.example.foodbox.Models.CityNote;
import com.example.foodbox.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;


public class FoodFragment extends Fragment {
    private View food_view;

    private String dhaba_name;
    Button submit;
    Spinner spinner;
    RecyclerView dhaba_recyclerview;
    private DhabaAdapter adapter;
    private FirebaseFirestore db=FirebaseFirestore.getInstance();
    ArrayList<String> spinList=new ArrayList<>();
    CollectionReference colref;
    private Query query;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        food_view= inflater.inflate(R.layout.fragment_food, container, false);
        spinner=food_view.findViewById(R.id.dhaba_spinner);



        spinList.add("Select City");
        db.collection("City").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                for(DocumentSnapshot documentSnapshot:queryDocumentSnapshots){
                    CityNote cityNote=documentSnapshot.toObject(CityNote.class);
//                    String docId=documentSnapshot.getId();
                    spinList.add(cityNote.getCityName());
                }
                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, spinList);
                arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner.setAdapter(arrayAdapter);


            }
        });
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String c=spinner.getSelectedItem().toString();
                if(!c.equals("Select City")){
//                    submit.setVisibility(View.GONE);
                    Bundle bundle=new Bundle();
                    bundle.putString("City",c);
                    Fragment fragment=new DhabaFragment();
                    fragment.setArguments(bundle);
                    FragmentTransaction transaction=getActivity().getSupportFragmentManager().beginTransaction();
                    transaction.replace(R.id.dhaba_cont,fragment).commit();

                }else {
                    Toast.makeText(getContext(), "Please select location", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


//        submit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                String c=spinner.getSelectedItem().toString();
//                colref=db.collection("admins");
//                query=colref.whereEqualTo("Address","Haryana");
//                FirestoreRecyclerOptions<DhabaProfile> options=new FirestoreRecyclerOptions.Builder<DhabaProfile>()
//                        .setQuery(query,DhabaProfile.class)
//                        .build();
//                adapter=new DhabaAdapter(options);
//                dhaba_recyclerview.setLayoutManager(new LinearLayoutManager(getContext()));
//                dhaba_recyclerview.setAdapter(adapter);
//
//
//
//            }
//        });


        return food_view;
    }

}
