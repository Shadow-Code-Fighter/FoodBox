package com.example.foodbox.Fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Spinner;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.foodbox.Adapter.DhabaAdapter;
import com.example.foodbox.Menu;
import com.example.foodbox.Models.DhabaProfile;
import com.example.foodbox.R;
import com.example.foodbox.WrapContentLinearLayoutManager;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;


public class DhabaFragment extends Fragment {

    private View dhaba_view;
    Spinner spinner;
    RecyclerView dhaba_recyclerview;
    private DhabaAdapter adapter;
    private FirebaseFirestore db=FirebaseFirestore.getInstance();
    ArrayList<String> spinList=new ArrayList<>();
    CollectionReference colref;
    private Query query;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        dhaba_view= inflater.inflate(R.layout.fragment_dhaba, container, false);
        dhaba_recyclerview=dhaba_view.findViewById(R.id.dhaba_recyclerview);
        dhaba_recyclerview.setLayoutManager(new WrapContentLinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL,false));
        Bundle bundle=getArguments();
        String city=bundle.getString("City");
        colref=db.collection("admins");
        query=colref.whereEqualTo("Address",city);
        FirestoreRecyclerOptions<DhabaProfile> options=new FirestoreRecyclerOptions.Builder<DhabaProfile>()
                .setQuery(query,DhabaProfile.class)
                .build();
        adapter=new DhabaAdapter(options);
//        dhaba_recyclerview.setLayoutManager(new LinearLayoutManager(getContext()));
        dhaba_recyclerview.setAdapter(adapter);

        adapter.setOnItemClickListener(new DhabaAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(DocumentSnapshot documentSnapshot, int position) {
                Intent i= new Intent(getActivity(), Menu.class);
                i.putExtra("path",documentSnapshot.getReference().getPath());
                i.putExtra("id",documentSnapshot.getReference().getId());
                i.putExtra("rest_name",documentSnapshot.getString("Restaurant"));
                startActivity(i);

            }
        });



        return dhaba_view;
    }
    @Override
    public void onStart() {
        super.onStart();
        try {
            adapter.startListening();
        }catch (Exception e)
        {
//            Toast.makeText(getApplicationContext(),"Network Error",Toast.LENGTH_SHORT).show();
        }


    }

    @Override
    public void onStop() {
        super.onStop();
        try {
            adapter.stopListening();
        }catch (Exception e)
        {
//            Toast.makeText(getApplicationContext(),"Network Error",Toast.LENGTH_SHORT).show();
        }
    }

}
