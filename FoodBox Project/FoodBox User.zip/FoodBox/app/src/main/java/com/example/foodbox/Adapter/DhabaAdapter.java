package com.example.foodbox.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.foodbox.Models.DhabaProfile;
import com.example.foodbox.R;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.DocumentSnapshot;
import com.squareup.picasso.Picasso;

public class DhabaAdapter extends FirestoreRecyclerAdapter<DhabaProfile, DhabaAdapter.DhabaHolder> {

    private OnItemClickListener listener;
    /**
     * Create a new RecyclerView adapter that listens to a Firestore Query.  See {@link
     * FirestoreRecyclerOptions} for configuration options.
     *
     * @param options
     */

    public DhabaAdapter(@NonNull FirestoreRecyclerOptions<DhabaProfile> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull DhabaHolder holder, int position, @NonNull DhabaProfile model) {

        holder.dhaba_name.setText(model.getRestaurant());
        holder.dhaba_add.setText(model.getAddress());
        Picasso.get().load(model.getAdminImage()).into(holder.dhaba_image);

    }

    @NonNull
    @Override
    public DhabaHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.dhaba_list,parent,false);
        return new DhabaHolder(view);
    }

    public class DhabaHolder extends RecyclerView.ViewHolder {
        TextView dhaba_add,dhaba_name,dhaba_city;
        ImageView dhaba_image;
        public DhabaHolder(@NonNull View itemView) {
            super(itemView);

            dhaba_add=itemView.findViewById(R.id.dhaba_add);
            dhaba_name=itemView.findViewById(R.id.dhaba_name);
            dhaba_city=itemView.findViewById(R.id.dhaba_city);
            dhaba_image=itemView.findViewById(R.id.dhaba_image);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position=getAdapterPosition();
                    if(position!=RecyclerView.NO_POSITION && listener!=null) {
                        listener.onItemClick(getSnapshots().getSnapshot(position), position);
                    }
                }
            });
        }
    }
    //
    public interface OnItemClickListener{
        void onItemClick(DocumentSnapshot documentSnapshot,int position);

    }
    public  void setOnItemClickListener(OnItemClickListener listener){
        this.listener=listener;
    }
}
