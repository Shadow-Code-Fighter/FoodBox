package com.example.foodbox;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.foodbox.Adapter.MenuAdapter;
import com.example.foodbox.Models.CartNote;
import com.example.foodbox.Models.MenuNote;
import com.example.foodbox.User.Users_Dashboard;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.squareup.picasso.Picasso;


public class Menu extends AppCompatActivity {
    private String rest_id, restPath, rest_name;
    RecyclerView menu_recyclerview;
    FirebaseAuth mAuth;
    Button dhaba,tiifin,add_cart,view_cart;
    ImageView tiffinImage;
    LinearLayout tiffinView;
    TextView b_price,l_price,d_price;
    CheckBox breakfast,lunch,dinner;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    private FirebaseUser currentuser;
    private CollectionReference restref,colref;
    private Query query;
    MenuAdapter adapter;
    String brk,lun,dinn,userid;
    String brk_txt,lun_txt,dinn_txt;
    private String value="cart";
    int br_price=0,lu_price=0,din_price=0,total=0,num=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        mAuth = FirebaseAuth.getInstance();
        currentuser=mAuth.getCurrentUser();


        final Intent data = getIntent();
        rest_id=data.getStringExtra("id");
        restPath = data.getStringExtra("path");
        rest_name=data.getStringExtra("rest_name");
        menu_recyclerview = findViewById(R.id.menu_recyclerview);
        tiffinImage=findViewById(R.id.tiffinImsge);
        dhaba=findViewById(R.id.dabha);
        tiifin=findViewById(R.id.tiffin);
        tiffinView=findViewById(R.id.tiffinview);
        b_price=findViewById(R.id.b_price);
        l_price=findViewById(R.id.l_price);
        d_price=findViewById(R.id.d_price);
        view_cart=findViewById(R.id.view_cart);
        add_cart=findViewById(R.id.addCart);
        breakfast=findViewById(R.id.brkfast);
        lunch=findViewById(R.id.lunch);
        dinner=findViewById(R.id.dinner);
        userid=currentuser.getUid();

        colref=db.collection("users").document(userid).collection("cart");


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setLogo(R.drawable.ic_restaurant_white);
        getSupportActionBar().setTitle(" "+rest_name);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.arrow_back_icon);

        showMenu();
        breakfast.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Perform action based on checkbox state
                if (isChecked) {
                    brk_txt=breakfast.getText().toString();
                    br_price=Integer.parseInt(brk);
                } else {
                    br_price=0;
                }
            }
        });
        lunch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Perform action based on checkbox state
                if (isChecked) {
                    lun_txt=lunch.getText().toString();
                    lu_price=Integer.parseInt(lun);
                } else {
                    lu_price=0;
                }
            }
        });
        dinner.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Perform action based on checkbox state
                if (isChecked) {
                    dinn_txt=dinner.getText().toString();
                    din_price=Integer.parseInt(dinn);
                } else {
                    din_price=0;
                }
            }
        });




        add_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(breakfast.isChecked() || lunch.isChecked() || dinner.isChecked()){
//                    total=br_price+lu_price+din_price;
                    if(breakfast.isChecked()){
                        CartNote note=new CartNote(brk_txt,br_price,num,br_price,rest_id,value,rest_name);
                        colref.add(note);
                    }
                    if(lunch.isChecked()){
                        CartNote note1=new CartNote(lun_txt,lu_price,num,lu_price,rest_id,value,rest_name);
                        colref.add(note1);
                    }
                    if(dinner.isChecked()){
                        CartNote note2=new CartNote(dinn_txt,din_price,num,din_price,rest_id,value,rest_name);
                        colref.add(note2);
                    }
                    Toast.makeText(getApplicationContext(),"Successfully Added in Your Cart ",Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(getApplicationContext(),"Select at least one",Toast.LENGTH_SHORT).show();
                }

            }
        });

        dhaba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dhaba.setBackgroundColor(getResources().getColor(R.color.green));
                tiifin.setBackgroundColor(getResources().getColor(R.color.lightGreen));
                tiffinView.setVisibility(View.GONE);
                menu_recyclerview.setVisibility(View.VISIBLE);

            }
        });

        tiifin.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                tiifin.setBackgroundColor(getResources().getColor(R.color.green));
                dhaba.setBackgroundColor(getResources().getColor(R.color.lightGreen));
                menu_recyclerview.setVisibility(View.GONE);
                tiffinView.setVisibility(View.VISIBLE);
                db.document(restPath).collection("Tiffin").document("Menu").get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        brk=documentSnapshot.getString("Breakfast");
                        lun=documentSnapshot.getString("Lunch");
                        dinn=documentSnapshot.getString("Lunch");
                        b_price.setText("Price: "+brk);
                        l_price.setText("Price: "+lun);
                        d_price.setText("Price: "+dinn);

                        Picasso.get().load(documentSnapshot.getString("Tiffin Image")).into(tiffinImage);

                    }


                });
            }
        });
        view_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), Users_Dashboard.class);
                i.putExtra("value",1);
                i.putExtra("userID",userid);
                startActivity(i);
            }
        });

    }

    private void showMenu() {
        menu_recyclerview.setLayoutManager(new WrapContentLinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL,false));

        restref=db.document(restPath).collection("Menu");
        query=restref;
        FirestoreRecyclerOptions<MenuNote> options = new FirestoreRecyclerOptions.Builder<MenuNote>()
                .setQuery(query, MenuNote.class)
                .build();
        adapter = new MenuAdapter(options);
//        menu_recyclerview.setLayoutManager(new LinearLayoutManager(this));
        menu_recyclerview.setAdapter(adapter);
        adapter.setOnItemClickListener(new MenuAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(DocumentSnapshot documentSnapshot, int position) {
                MenuNote menuNote = documentSnapshot.toObject(MenuNote.class);
                String id = documentSnapshot.getId();
                String path = documentSnapshot.getReference().getPath();
//                Toast.makeText(getApplicationContext(),"id"+id,Toast.LENGTH_LONG).show();
                Intent i = new Intent(getApplicationContext(), Food_details.class);
                i.putExtra("id", id);
                i.putExtra("rest_id", rest_id);
                i.putExtra("path", path);
                i.putExtra("rest_name", rest_name);
                startActivity(i);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        try {
            adapter.startListening();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Network Error", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {
            adapter.stopListening();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Network Error", Toast.LENGTH_SHORT).show();
        }
    }
}

