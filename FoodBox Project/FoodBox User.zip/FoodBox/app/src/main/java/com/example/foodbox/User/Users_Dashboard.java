package com.example.foodbox.User;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.example.foodbox.About;
import com.example.foodbox.Fragments.AccountFragment;
import com.example.foodbox.Fragments.CartFragment;
import com.example.foodbox.Fragments.FoodFragment;
import com.example.foodbox.Fragments.HomeFragment;
import com.example.foodbox.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Users_Dashboard extends AppCompatActivity {

    BottomNavigationView navigationView;

    Toolbar toolbar;

   /* HomeFragment homeFragment = new HomeFragment();
    FoodFragment foodFragment = new FoodFragment();
    AccountFragment accountFragment = new AccountFragment();
    CartFragment cartFragment = new CartFragment(); */

    private FirebaseUser firebaseUser;
    private Integer value=1,value1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users_dashboard);

        BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
                = new BottomNavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedFragment=null;
                switch (item.getItemId()) {
                    case R.id.nav_home:
                        selectedFragment=new HomeFragment();
                        break;
                    case R.id.nav_food:
                        selectedFragment=new FoodFragment();
                        break;
                    case R.id.nav_account:
                        selectedFragment=new AccountFragment();
                        break;

                    case R.id.nav_cart:
                        selectedFragment=new CartFragment();
                        break;
                }
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,selectedFragment).addToBackStack(null).commit();
                return true;
            }
        };



       // nav_view.setSelectedItemId(R.id.nav_account);

        checksetup();
        Intent i=getIntent();
        value1=i.getIntExtra("value",0);

        //botom navigation
        navigationView = findViewById(R.id.btnav_view);
        navigationView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);



        toolbar = findViewById(R.id.toolbar);

        toolbar.setTitle("FoodBox");
        setSupportActionBar(toolbar);


        //start from Cart fragment
        if(value1==1 && value==1)
        {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new CartFragment()).commit();
            navigationView.setSelectedItemId(R.id.nav_cart);
        }
        //start from home fragment
        else{
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new HomeFragment()).commit();
            navigationView.setSelectedItemId(R.id.nav_home);
        }
    }

    private void checksetup() {
        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        if(firebaseUser==null)
        {
            Intent i = new Intent(Users_Dashboard.this, user_login.class);
            startActivity(i);
            finish();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menubar) {
        // Inflate the Menu; this adds items to the action bar if it is present.
        MenuInflater inflater=getMenuInflater();
        getMenuInflater().inflate(R.menu.menu_bar, menubar);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.action_share)
        {
            Toast.makeText(getApplicationContext(),"Share Selected",Toast.LENGTH_SHORT).show();


            Intent intent=new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, "Check out this Food Application");
            intent.putExtra(Intent.EXTRA_TEXT, "Your Application Link Here");
            startActivity(Intent.createChooser(intent, "Share Via"));
        }
        else if(id==R.id.action_about) {
            Intent intent = new Intent(getApplicationContext(), About.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}
