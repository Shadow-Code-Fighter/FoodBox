package com.example.foodbox.User;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.foodbox.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class forgot_password extends AppCompatActivity {

    private Button login, reset;
    private EditText txtEmail;

    private String mail;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        txtEmail=findViewById(R.id.email);
        login=findViewById(R.id.loginbtn);
        reset=findViewById(R.id.resetlink);

        mAuth=FirebaseAuth.getInstance();

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(forgot_password.this, user_login.class);
                startActivity(i);
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateData();
            }
        });
    }

    private void validateData() {
        mail=txtEmail.getText().toString();
        if(mail.isEmpty()){
            txtEmail.setError("It is Required Fields");
        }else{
            forgetpass();
        }
    }

    private void forgetpass() {
        mAuth.sendPasswordResetEmail(mail)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful())
                        {
                            Toast.makeText(forgot_password.this,"Check Your Email",Toast.LENGTH_SHORT).show();
                            Intent i=new Intent(forgot_password.this,user_login.class);
                            startActivity(i);
                            finish();
                        }else {
                            Toast.makeText(forgot_password.this, "Error :"+ task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}
