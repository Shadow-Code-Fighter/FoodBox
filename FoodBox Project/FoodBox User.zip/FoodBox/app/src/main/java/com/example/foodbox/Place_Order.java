package com.example.foodbox;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.foodbox.Payment.Payment;

public class Place_Order extends AppCompatActivity {

    EditText p_name,p_phone,p_pin,flat_no,parea;
    Button plcd_order;
    private String uname,area,order,hotelId,userid,phone,pin,flat,rest_name,order_id,cust_id;
    private Integer total;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_order);

        p_name=findViewById(R.id.p_name);
        p_phone=findViewById(R.id.p_phone);
        flat_no=findViewById(R.id.flat_no);
        parea=findViewById(R.id.area);
        p_pin=findViewById(R.id.p_pin);
        plcd_order=findViewById(R.id.pl_order);
        Intent i=getIntent();
        order=i.getStringExtra("order");
        hotelId=i.getStringExtra("hotelId");
        total=i.getIntExtra("total",0);
        userid=i.getStringExtra("userid");
        rest_name=i.getStringExtra("rest_name");
        order_id=i.getStringExtra("order_id");
        cust_id=i.getStringExtra("cust_id");

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setLogo(R.drawable.address_icon);
        getSupportActionBar().setTitle("  Fill Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.arrow_back_icon);


        plcd_order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(p_name.getText().toString().isEmpty() || p_phone.getText().toString().isEmpty() || p_pin.getText().toString().isEmpty()
                        || flat_no.getText().toString().isEmpty() || parea.getText().toString().isEmpty())

//                {
//                    p_name.setError("Required");
//                    p_name.requestFocus();
//                    p_phone.requestFocus();
//                    p_pin.requestFocus();
//                    flat_no.requestFocus();
//                    area.requestFocus();
//                    return;
//                }


                if(p_name.getText().toString().isEmpty()){
                    p_name.setError("Name is required");
                    p_name.requestFocus();
                    return;
                }
                if(p_phone.getText().toString().isEmpty()){
                    p_phone.setError("Phone no. is required");
                    p_phone.requestFocus();
                    return;
                }
                if(p_pin.getText().toString().isEmpty()){
                    p_pin.setError("Pincode is required");
                    p_pin.requestFocus();
                    return;
                }
                if(flat_no.getText().toString().isEmpty()){
                    flat_no.setError("Flat no. is required");
                    flat_no.requestFocus();
                    return;
                }
                if(parea.getText().toString().isEmpty()){
                    parea.setError("Road/Area is required");
                    parea.requestFocus();
                    return;
                }
                phone=p_phone.getText().toString();
                pin=p_pin.getText().toString();
                flat=flat_no.getText().toString();
                uname=p_name.getText().toString();
                area=parea.getText().toString();
                if(phone.length()!=10)
                {
                    p_phone.setError("Invalid Phone no.");
                    p_phone.requestFocus();
                    return;
                }
                else if(pin.length()!=6)
                {
                    p_pin.setError("Invalid Pincode.");
                    p_pin.requestFocus();
                    return;
                }
                else{
                    Intent intent=new Intent(getApplicationContext(), Payment.class);
                    intent.putExtra("order",order);
                    intent.putExtra("total",total);
                    intent.putExtra("hotelId",hotelId);
                    intent.putExtra("userid",userid);
                    intent.putExtra("rest_name",rest_name);
                    intent.putExtra("order_id",order_id);
                    intent.putExtra("cust_id",cust_id);
                    intent.putExtra("uname",uname);
                    intent.putExtra("pincode",pin);
                    intent.putExtra("flat",flat);
                    intent.putExtra("area",area);
                    intent.putExtra("phone",phone);
                    startActivity(intent);
                }
            }
        });

    }
}
