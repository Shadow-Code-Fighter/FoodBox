package com.example.foodbox.Models;

public class CityNote {
    private String CityName;

    public CityNote() {
    }

    public CityNote(String cityName) {
        CityName = cityName;
    }

    public String getCityName() {
        return CityName;
    }

    public void setCityName(String cityName) {
        CityName = cityName;
    }
}
