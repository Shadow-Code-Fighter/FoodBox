package com.example.foodbox.Payment;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.foodbox.Models.OrderHotelNote;
import com.example.foodbox.Models.OrderNote;
import com.example.foodbox.Models.UserDetailNote;
import com.example.foodbox.R;
import com.example.foodbox.User.Users_Dashboard;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.WriteBatch;

import java.util.List;

public class Payment extends AppCompatActivity {

    RadioButton cod;
    RadioGroup radioGroup;
    Button conf_payment;
    private  int i;
    private String selectedPayment;
    private String uname,area,order,hotelId,userid,phone,pin,flat,rest_name,order_id,cust_id,hotel_uid;
    private FirebaseAuth mAuth=FirebaseAuth.getInstance();
    private FirebaseUser currentuser;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private DatabaseReference databaseReference;
    private Integer total;
    private String status="Pending",u_email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        cod=findViewById(R.id.cod);
//        razorpay=findViewById(R.id.razorpay);

        Intent intent=getIntent();
        order=intent.getStringExtra("order");
        total=intent.getIntExtra("total",0);
        hotelId=intent.getStringExtra("hotelId");
        userid=intent.getStringExtra("userid");
        rest_name=intent.getStringExtra("rest_name");
        order_id=intent.getStringExtra("order_id");
        cust_id=intent.getStringExtra("cust_id");
        uname=intent.getStringExtra("uname");
        pin=intent.getStringExtra("pincode");
        flat=intent.getStringExtra("flat");
        area=intent.getStringExtra("area");
        phone=intent.getStringExtra("phone");

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setLogo(R.drawable.payments_icon);
        getSupportActionBar().setTitle("  Select Payment Method");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.arrow_back_icon);

        radioGroup=findViewById(R.id.radioGroup);
        conf_payment=findViewById(R.id.conf_payment);

        i=radioGroup.getCheckedRadioButtonId();
        RadioButton rb=radioGroup.findViewById(i);
        currentuser=mAuth.getCurrentUser();

        //fetching hotel uid
        db.collection("admins").document(hotelId).get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        UserDetailNote userNote = documentSnapshot.toObject(UserDetailNote.class);
                        hotel_uid=userNote.getUid();
//                        Toast.makeText(getApplicationContext(),"uid"+hotel_uid,Toast.LENGTH_LONG).show();
                    }
                });

        //fetch user email_id
        db.collection("users").document(currentuser.getUid())
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        UserDetailNote userDetailNote=documentSnapshot.toObject(UserDetailNote.class);
                        u_email=userDetailNote.getEmail();
//                        Toast.makeText(getApplicationContext(),"user"+u_email,Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(),"Error: "+e,Toast.LENGTH_SHORT).show();
                    }
                });

        //Confirm payment method
        conf_payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i=radioGroup.getCheckedRadioButtonId();
                RadioButton rb=radioGroup.findViewById(i);
                if(i==-1)
                {
                    Toast.makeText(getApplicationContext(),"Please select payment method",Toast.LENGTH_SHORT).show();
                }
                else{
                    selectedPayment=rb.getText().toString();
                    //CoD payment
                    if(selectedPayment.equals("COD(Cash On Delivery)"))
                    {
                        //add order details in user collection
                        OrderNote note=new OrderNote(order,total,hotelId,uname,pin,phone,flat,area,rest_name,order_id,cust_id,selectedPayment,status);
                        db.collection("users").document(userid).collection("orderdetails")
                                .add(note);

                        //add order details in hotel collection
                        OrderHotelNote hotelNote= new OrderHotelNote(order,total,userid,uname,pin,phone,flat,area,order_id,cust_id,selectedPayment,status,u_email);
                        db.collection("admins").document(hotelId).collection("orderdetails")
                                .add(hotelNote);

                        //delete items from cart
                        db.collection("users").document(userid).collection("cart").whereEqualTo("value","cart")
                                .get()
                                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                    @Override
                                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                                        WriteBatch batch=db.batch();
                                        List<DocumentSnapshot> snapshotList=queryDocumentSnapshots.getDocuments();
                                        for(DocumentSnapshot snapshot:snapshotList){
                                            batch.delete(snapshot.getReference());
                                        }
                                        batch.commit();

                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(getApplicationContext(),""+e.getMessage(),Toast.LENGTH_SHORT).show();
                                    }
                                });
                        Toast.makeText(getApplicationContext(),"Order Placed Successfully",Toast.LENGTH_LONG).show();

                        //send msg on email
//                        sendMail();

                        //sucess message
                        View view= LayoutInflater.from(Payment.this).inflate(R.layout.activity_success_status,null);
                        AlertDialog.Builder builder=new AlertDialog.Builder(Payment.this);
                        builder.setCancelable(false)
                                .setView(view)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Intent i=new Intent(getApplicationContext(), Users_Dashboard.class);
                                        i.addFlags(i.FLAG_ACTIVITY_NEW_TASK | i.FLAG_ACTIVITY_CLEAR_TASK);
                                        startActivity(i);
                                        finish();
                                    }
                                });
                        AlertDialog alert = builder.create();
                        alert.show();
                    }

                    //Online Payment



                }
            }
        });
    }

//    private void sendMail() {
//
//        String mail = u_email;
//        String message = " Thank You for order "+uname+", Your order placed successfully \n Your orderId is "+order_id+"\nYour order is:\n"+order;
//        String subject = "Order Details";
//
//        //Send Mail
//        JavaMailAPI javaMailAPI = new JavaMailAPI(this,mail,subject,message);
//        javaMailAPI.execute();
//    }
}
