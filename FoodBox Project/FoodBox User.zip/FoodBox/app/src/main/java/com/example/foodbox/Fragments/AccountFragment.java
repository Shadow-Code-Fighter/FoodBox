package com.example.foodbox.Fragments;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.foodbox.AccountFragment.Contact_Us;
import com.example.foodbox.AccountFragment.Payment_Method;
import com.example.foodbox.R;
import com.example.foodbox.AccountFragment.SeeOrderDetails;
import com.example.foodbox.User.user_login;
import com.example.foodbox.AccountFragment.User_Profile;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;


public class AccountFragment extends Fragment {

    private View account_view;
    Button edit_profile;
    RelativeLayout order_details,logout,contact,feedback,payments,rateus;

    ImageView profile_image;
    TextView name,phone;
    private FirebaseAuth mAuth;
    private FirebaseStorage firebaseStorage;
    private StorageReference storageReference;
    private FirebaseUser currentuser;
    private FirebaseFirestore db=FirebaseFirestore.getInstance();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        account_view=inflater.inflate(R.layout.fragment_account,container,false);

        profile_image=account_view.findViewById(R.id.profile_image);
        name=account_view.findViewById(R.id.user_name);
        phone=account_view.findViewById(R.id.phone);

        mAuth=FirebaseAuth.getInstance();
        currentuser=mAuth.getCurrentUser();

        edit_profile=account_view.findViewById(R.id.edit_profile);
        order_details=account_view.findViewById(R.id.order_details);
        payments=account_view.findViewById(R.id.payments);
        logout=account_view.findViewById(R.id.logout);
        contact=account_view.findViewById(R.id.contact_us);
        feedback=account_view.findViewById(R.id.feedback);
        rateus=account_view.findViewById(R.id.rateus);


        storageReference = FirebaseStorage.getInstance().getReference().child("Profile Images");
        db.collection("users").document(currentuser.getUid()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {

//                if (documentSnapshot.exists()) {
//                    String imageUrl = documentSnapshot.getString("image");
//                    if (imageUrl != null) {
//                        Picasso.get().load(imageUrl).into(profile_image);
//                    }
//                }

                name.setText(documentSnapshot.getString("name"));
                phone.setText(documentSnapshot.getString("phone"));
                String retriveprofileimage=documentSnapshot.getString("image");
                Picasso.get().load(retriveprofileimage).into(profile_image);

                // Get the profile image URL from Firestore
                String profileImageUrl = documentSnapshot.getString("image");

                // Check if the profile image URL is null or empty
                if (profileImageUrl == null || profileImageUrl.isEmpty()) {
                    // Set the default profile image if the profile image URL is null or empty
                    profile_image.setImageResource(R.drawable.profile_icon);
                } else {
                    // Load the profile image using Glide
                    Picasso.get().load(documentSnapshot.getString("image")).into(profile_image);
                }

            }
        });



        edit_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), User_Profile.class);
                startActivity(i);
            }
        });
        order_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getActivity(), SeeOrderDetails.class);
                startActivity(i);
            }
        });
        payments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getActivity(), Payment_Method.class);
                startActivity(i);
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent i = new Intent(getActivity(), user_login.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
                getActivity().finish();
            }
        });
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getActivity(), Contact_Us.class);
                startActivity(i);
            }
        });
        rateus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(),"rate us selected",Toast.LENGTH_SHORT).show();
            }
        });
        feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFeddbackDialog(Gravity.CENTER);
            }
        });

        return account_view;
    }
    private void openFeddbackDialog(int gravity){
        Dialog dialog= new Dialog(getContext());
        dialog.setContentView(R.layout.feedback_layout);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
        dialog.setCancelable(false);
        dialog.show();

        EditText edit_feedback=dialog.findViewById(R.id.edit_feedback);
        Button send = dialog.findViewById(R.id.send);
        Button cancel = dialog.findViewById(R.id.cancel);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String feedback=edit_feedback.getText().toString();

                Intent i=new Intent(Intent.ACTION_SEND);

//                i.setData(Uri.parse("mailto:foodservice.cuh@gmail.com"));
//                i.putExtra(Intent.EXTRA_SUBJECT, "User feedback");
//                i.putExtra(Intent.EXTRA_TEXT, feedback);

                i.setType("text/mail");
                String subject="Feedback from FoodBox";
                i.putExtra(Intent.EXTRA_EMAIL,new String[]{"foodservice.cuh@gmail.com"});
                i.putExtra(Intent.EXTRA_SUBJECT,"User feedback");
                i.putExtra(Intent.EXTRA_TEXT,"Name :"+ name+"\n"+"User Feedback :"+feedback);
                startActivity(Intent.createChooser(i,"Feedback With"));
            }
        });

//        Window window = dialog.getWindow();
//        if (window==null){
//            return;
//        }
//
//        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
//        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//
//        WindowManager.LayoutParams windowAttributes = window.getAttributes();
//        windowAttributes.gravity = gravity;
//        window.getAttributes();

    }
}