package com.example.foodbox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Success_Status extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success_status);
    }
}